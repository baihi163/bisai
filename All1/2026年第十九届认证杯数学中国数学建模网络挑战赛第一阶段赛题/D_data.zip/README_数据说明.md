# 共享充电宝的投放配置数据包说明

## 一、用途
本数据包与“商业园区示意地图”一一对应，适用于共享充电宝布点、容量配置与基础调度建模。
本数据包只包含通过简单调查得到的数据，不包含更复杂的人流转移矩阵、异常情景表或精细经营参数。

## 二、与地图的对应关系
地图中的 8 个区域（Z1-Z8）与 10 个候选站点（S1-S10）的坐标及命名与数据文件保持一致。

### 区域对应
- Z1 主入口广场（Entry Plaza）
- Z2 停车场连廊（Parking Link）
- Z3 餐饮东区（Dining East）
- Z4 咖啡轻食区（Coffee Area）
- Z5 中庭休闲区（Central Court）
- Z6 零售店铺区（Retail Area）
- Z7 娱乐影院区（Cinema Zone）
- Z8 夜间餐饮区（Night Dining）

### 候选站点对应
- S1 入口广场南侧
- S2 停车连廊北口
- S3 餐饮东区连廊口
- S4 咖啡区步行街口
- S5 中庭核心点
- S6 零售区中轴点
- S7 中庭东侧节点
- S8 零售东侧节点
- S9 影院门前
- S10 夜间餐饮街口

## 三、文件说明

### 1. zones.csv
区域信息表。
字段：
- zone_id：区域编号
- zone_name_cn：中文名称
- zone_name_en：英文名称
- zone_type：区域类型
- center_x, center_y：与示意图一致的平面坐标
- is_entry：是否入口区（1 是，0 否）
- is_anchor：是否核心吸引区（1 是，0 否）

### 2. sites.csv
候选站点表。
字段：
- site_id：站点编号
- site_name_cn：站点中文名称
- x, y：与示意图一致的平面坐标
- install_limit：该点位理论最大可安装容量（以插槽数计）

### 3. zone_site_distance.csv
区域到站点的步行距离表。
字段：
- zone_id：需求发生区域
- site_id：候选站点
- walk_distance_m：区域到站点的步行距离（米）

说明：
- 距离为人员实测得到的原始数据，示意图上并未标出具体路线的折绕情况；
- 该距离可直接用于最近站点分配和目标函数构造。

### 4. site_site_distance.csv
站点间距离表。
字段：
- from_site, to_site：起止站点
- distance_m：站点间距离（米）

### 5. demand_minimal.csv
字段：
- day_type：日期类型（工作日 / 周末）
- time_slot：时间段
- zone_id：需求区域
- borrow_demand_mean：该区域该时段平均借出需求
- return_demand_mean：该区域该时段平均归还需求
- demand_std：需求波动的尺度

### 6. equipment.csv
柜机规格表。
字段：
- type：规格名称
- capacity：容量（插槽数）
- fixed_cost_yuan：固定建设成本（元）

### 7. global_params.csv
全局参数表。
字段：
- parameter：参数名
- value：参数值
- description：中文说明